/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.estacionamiento;

//import java.time.LocalDateTime;
/**
 *
 * @author chioc
 */
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Date;

class Vehiculo {

    private String placa;
    private String tipo;
    private LocalDateTime horaEntrada;
    private LocalDateTime horaSalida;
    private LocalDateTime horaInicioEstacionado;
    private LocalDateTime horaFinEstacionado;
    private Date horaEstacionado;

    public Vehiculo(String placa, String tipo, LocalDateTime horaEntrada) {
        this.placa = placa;
        this.tipo = tipo;
        this.horaEntrada = horaEntrada;
    }

    public void setHoraSalida(LocalDateTime horaSalida) {
        this.horaSalida = horaSalida;
    }

    public void setHoraInicioEstacionado(LocalDateTime horaInicioEstacionado) {
        this.horaInicioEstacionado = horaInicioEstacionado;
    }

    public void setHoraFinEstacionado(LocalDateTime horaFinEstacionado) {
        this.horaFinEstacionado = horaFinEstacionado;
    }

    public int calcularTiempoEstacionado() {
        if (horaEntrada == null || horaSalida == null) {
            return 0;
        }

        Duration duracion = Duration.between(horaEntrada, horaSalida);
        return (int) duracion.toMinutes();
    }

    public double calcularImporte() {
        long minutosEstacionado = calcularTiempoEstacionado();
        if (tipo.equalsIgnoreCase("Oficial")) {
            return 0; // Los oficiales no pagan
        } else if (tipo.equalsIgnoreCase("Residente")) {
            return minutosEstacionado * 1; // Residentes pagan $1 por minuto
        } else {
            return minutosEstacionado * 3; // No residentes pagan $3 por minuto
        }
    }

    public String getPlaca() {
        return placa;
    }

    public LocalDateTime getHoraEntrada() {
        return horaEntrada;
    }

    public String getTipo() {
        return tipo;
    }

    public LocalDateTime getHoraInicioEstacionado() {
        return horaInicioEstacionado;
    }

    public Date getHoraEstacionado() {
        return horaEstacionado;
    }

    public LocalDateTime getHoraFinEstacionado() {
        return horaFinEstacionado;
    }

    public LocalDateTime getHoraSalida() {
        return horaEntrada;
    }
}
