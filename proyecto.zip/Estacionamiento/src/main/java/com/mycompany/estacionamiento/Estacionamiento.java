/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.estacionamiento;

/**
 *
 * @author chioc
 */
import Conexion.Logica;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Estacionamiento extends JFrame {

    private Map<String, Vehiculo> vehiculos;
    private DefaultTableModel tableModel;
    private JTable table;
    private JTextField placaField, diaInicioField, horaInicioField, diaFinField, horaFinField;
    private JTextArea registrosArea;
    private JLabel placaLabel, tipoLabel, montoLabel, horaInicioLabel, horaFinLabel;
    private JComboBox<String> tipoComboBox;
    
   
 


    public Estacionamiento() {
        
        super("Estacionamiento");
       
        vehiculos = new HashMap<>();
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Inicio");
        tableModel.addColumn("Número de placa");
        tableModel.addColumn("Tiempo estacionado (min.)");
        tableModel.addColumn("Tipo");
        tableModel.addColumn("Cantidad a pagar");
        tableModel.addColumn("Fin");

        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        placaLabel = new JLabel("Placa:");
        placaField = new JTextField(10);

        JLabel filtroLabel = new JLabel("Filtrar por:");
        JLabel tipoFiltroLabel = new JLabel("Tipo de vehículo:");
        String[] tipos = {"Oficial", "Residente", "No residente"};
        tipoComboBox = new JComboBox<>(tipos);

        JLabel fechaInicioLabel = new JLabel("Fecha inicio (dd/mm/yyyy):");
        diaInicioField = new JTextField(10);
        JLabel horaInicioLabel = new JLabel("Hora inicio (hh:mm):");
        horaInicioField = new JTextField(10);

        JLabel fechaFinLabel = new JLabel("Fecha fin (dd/mm/yyyy):");
        diaFinField = new JTextField(10);
        JLabel horaFinLabel = new JLabel("Hora fin (hh:mm):");
        horaFinField = new JTextField(10);

        JButton entradaButton = new JButton("Registrar Entrada");
        entradaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarEntrada();
            }
        });

        JButton salidaButton = new JButton("Registrar Salida");
        salidaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarSalida();
            }
        });

        JButton filtrarButton = new JButton("Filtrar");
        filtrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // filtrar();
            }

        });

        JButton generarReporteButton = new JButton("Generar Reporte");
        generarReporteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generarReporte();
            }
        });

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonsPanel.add(entradaButton);
        buttonsPanel.add(salidaButton);
        buttonsPanel.add(generarReporteButton);

        JPanel registroPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        registroPanel.add(placaLabel);
        registroPanel.add(placaField);
        registroPanel.add(buttonsPanel);

        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(registroPanel, BorderLayout.NORTH);
        add(filtrarButton, BorderLayout.SOUTH);

        registrosArea = new JTextArea(10, 30);
        registrosArea.setEditable(false);
        //JScrollPane registrosScrollPane = new JScrollPane(registrosArea);

        JPanel registrosArea = new JPanel(new FlowLayout(FlowLayout.LEFT));
        registroPanel.add(placaLabel);
        registroPanel.add(placaField);
        registroPanel.add(entradaButton);
        registroPanel.add(salidaButton);

        JPanel filtroPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        filtroPanel.setLayout(new GridLayout(6, 2));
        filtroPanel.add(filtroLabel);
        filtroPanel.add(new JLabel());
        filtroPanel.add(tipoFiltroLabel);
        filtroPanel.add(tipoComboBox);
        filtroPanel.add(fechaInicioLabel);
        filtroPanel.add(diaInicioField);
        filtroPanel.add(horaInicioLabel);
        filtroPanel.add(horaInicioField);
        filtroPanel.add(fechaFinLabel);
        filtroPanel.add(diaFinField);
        filtroPanel.add(horaFinLabel);
        filtroPanel.add(horaFinField);
        filtroPanel.add(filtrarButton);

        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(registroPanel, BorderLayout.NORTH);
        //add(registrosScrollPane, BorderLayout.EAST);
        add(filtroPanel, BorderLayout.SOUTH);

        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
public void mostrarReporte()
    {
        Logica logica = new Logica();
        
        DefaultTableModel modelo = logica.mostrarReporte();
        
        table.setModel(modelo);
        
    }


    private void registrarEntrada() {
        String placa = placaField.getText();
        String[] tipos = {"Oficial", "Residente", "No residente"};
        String tipo = (String) JOptionPane.showInputDialog(this, "Seleccione el tipo de vehículo:",
                "Tipo de Vehículo", JOptionPane.PLAIN_MESSAGE, null, tipos, tipos[0]);

        if (tipo != null) {
            Vehiculo vehiculo = vehiculos.get(placa);
            if (vehiculo == null) {
                vehiculo = new Vehiculo(placa, tipo, LocalDateTime.now());
                vehiculos.put(placa, vehiculo);
                registrosArea.append("Entrada registrada para la placa: " + placa + " - Tipo: " + tipo + "\n");
                int tiempoEstacionado = vehiculo.calcularTiempoEstacionado();
                double cantidadPagar = vehiculo.calcularImporte();
                tableModel.addRow(new Object[]{LocalDateTime.now(), placa, tiempoEstacionado, tipo, cantidadPagar});
            } else {
                JOptionPane.showMessageDialog(this, "El vehículo con placa " + placa + " ya tiene una entrada registrada.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

   private void registrarSalida() {
    String placa = placaField.getText();
    Vehiculo vehiculo = vehiculos.get(placa);
    if (vehiculo != null) {
        vehiculo.setHoraSalida(LocalDateTime.now());
        vehiculo.setHoraFinEstacionado(LocalDateTime.now());
        registrosArea.append("Salida registrada para la placa: " + placa + "\n" +
                "Tiempo estacionado: " + vehiculo.calcularTiempoEstacionado() + " minutos\n" +
                "Monto a cobrar: $" + vehiculo.calcularImporte() + "\n");
        vehiculos.remove(placa);
        actualizarInfo(vehiculo);

        // Actualiza la tabla
        int fila = encontrarFilaEnTabla(placa);
        if (fila != -1) {
            tableModel.setValueAt(vehiculo.getHoraSalida(), fila, 6); // Actualiza la columna "Fin"
            tableModel.setValueAt(vehiculo.calcularImporte(), fila, 5); // Actualiza la columna "Cantidad a pagar"
        }
    } else {
        JOptionPane.showMessageDialog(this, "El vehículo con placa " + placa + " no tiene una entrada registrada.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private int encontrarFilaEnTabla(String placa) {
    for (int i = 0; i < tableModel.getRowCount(); i++) {
        if (tableModel.getValueAt(i, 1).equals(placa)) { //  la placa está en la segunda columna
            return i;
        }
    }
    return -1;
}


    private void filtrar() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        LocalDateTime diaInicio = LocalDateTime.parse(diaInicioField.getText() + " " + horaInicioField.getText(), formatter);
        LocalDateTime diaFin = LocalDateTime.parse(diaFinField.getText() + " " + horaFinField.getText(), formatter);

        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Reporte");

        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Número de placa");
        headerRow.createCell(1).setCellValue("Tipo");
        headerRow.createCell(2).setCellValue("Monto a pagar");
        headerRow.createCell(3).setCellValue("Hora de entrada");
        headerRow.createCell(4).setCellValue("Hora de salida");

        int rowNum = 1;
        for (Vehiculo vehiculo : vehiculos.values()) {
            LocalDateTime horaEntrada = vehiculo.getHoraEntrada();
            LocalDateTime horaSalida = vehiculo.getHoraSalida();
            if (horaEntrada != null && horaSalida != null
                    && horaEntrada.isAfter(diaInicio) && horaEntrada.isBefore(diaFin)) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(vehiculo.getPlaca());
                row.createCell(1).setCellValue(vehiculo.getTipo());
                row.createCell(2).setCellValue(vehiculo.calcularImporte());
                row.createCell(3).setCellValue(horaEntrada.format(formatter));
                row.createCell(4).setCellValue(horaSalida.format(formatter));
            }
        }

        try {
            FileOutputStream fileOut = new FileOutputStream("reporte.xlsx");
            workbook.write(fileOut);
            fileOut.close();
            workbook.close();
            JOptionPane.showMessageDialog(this, "Reporte generado y guardado como 'reporte.xlsx'.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al generar el reporte: " + ex.getMessage());
        }
    }

    /* Método para generar un informe filtrado por día y hora
    public List<String[]> generarReporte(Date fechaFiltro) {
        List<String[]> reporte = new ArrayList<>();

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

        for (Vehiculo vehiculo : vehiculos.values()) {
            // Filtra por día y hora
            if (vehiculo.getHoraEstacionado().after(fechaFiltro)) {
                String[] fila = new String[4];
                fila[0] = vehiculo.getPlaca();
                fila[1] = vehiculo.getTipo();
                fila[2] = sdf.format(vehiculo.getHoraInicioEstacionado());
                fila[3] = (vehiculo.getHoraFinEstacionado() != null) ? sdf.format(vehiculo.getHoraFinEstacionado()) : "";
                //fila[4] = vehiculo.calcularImporte();

                reporte.add(fila);
            }
        }

        return reporte;
        }*/
    private void generarReporte() {
        String diaInicio = diaInicioField.getText();
        String horaInicio = horaInicioField.getText();
        String diaFin = diaFinField.getText();
        String horaFin = horaFinField.getText();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Reporte");
            int rowNum = 0;

            for (Vehiculo vehiculo : vehiculos.values()) {
                LocalDateTime horaEntrada = vehiculo.getHoraEntrada();
                if (horaEntrada != null) {
                    String horaEntradaStr = horaEntrada.format(formatter);
                    if (horaEntradaStr.contains(diaInicio) && horaEntradaStr.contains(horaInicio)
                            && horaEntradaStr.contains(diaFin) && horaEntradaStr.contains(horaFin)) {
                        Row row = sheet.createRow(rowNum++);
                        row.createCell(0).setCellValue(vehiculo.getPlaca());
                        row.createCell(1).setCellValue(vehiculo.calcularTiempoEstacionado());
                        row.createCell(2).setCellValue(vehiculo.getTipo());
                        row.createCell(3).setCellValue(vehiculo.calcularImporte());
                    }
                }
            }

            try (FileOutputStream fileOut = new FileOutputStream("reporte.xlsx")) {
                workbook.write(fileOut);
            }

            JOptionPane.showMessageDialog(this, "Reporte generado correctamente.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al generar el reporte: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new Estacionamiento();
        

    }

    private void actualizarInfo(Vehiculo vehiculo) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void actualizarTablaInforme(List<String[]> informe) {
        // Método para actualizar la tabla en la interfaz gráfica con los resultados del informe
        DefaultTableModel modelo = (DefaultTableModel) table.getModel();
        modelo.setRowCount(0);

        for (String[] fila : informe) {
            modelo.addRow(fila);
        }
    }
    
    
}
