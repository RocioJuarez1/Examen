-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3305
-- Tiempo de generación: 29-02-2024 a las 03:24:15
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `estacionamiento`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculos`
--

CREATE TABLE `vehiculos` (
  `id_vehiculo` int(9) NOT NULL,
  `matricula` varchar(10) NOT NULL,
  `tiempo_estacionado` varchar(8) NOT NULL,
  `tipo` varchar(12) NOT NULL,
  `entrada` datetime NOT NULL,
  `salida` datetime NOT NULL,
  `importe` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `vehiculos`
--

INSERT INTO `vehiculos` (`id_vehiculo`, `matricula`, `tiempo_estacionado`, `tipo`, `entrada`, `salida`, `importe`) VALUES
(1, 'ABC-123', '7', 'oficial', '2024-02-28 13:23:00', '2024-02-28 13:30:00', 0),
(2, 'QWE-123', '20', 'oficial', '2024-02-28 18:01:10', '2024-02-28 18:22:05', 0),
(3, 'ERT-345', '19', 'residente', '2024-02-28 18:03:17', '2024-02-28 18:22:25', 19),
(4, 'ASD-345', '0', 'no residente', '2024-02-28 18:34:21', '1970-01-01 00:00:00', 0),
(5, 'CVB-765', '0', 'no residente', '2024-02-28 18:40:30', '1970-01-01 00:00:00', 0),
(6, 'JAS-123', '1', 'no residente', '2024-02-28 18:41:47', '2024-02-28 18:43:03', 3);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  ADD PRIMARY KEY (`id_vehiculo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  MODIFY `id_vehiculo` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
