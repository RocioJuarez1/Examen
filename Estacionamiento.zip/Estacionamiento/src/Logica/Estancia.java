package estacionamientoautomatizado;

import java.util.*;

/**
 * Estancia de un vehículo oficial
 */
public class Estancia {

    private Calendar horaEntrada;
    private Calendar horaSalida;

    public Estancia(Calendar horaEntrada, Calendar horaSalida) {
        super();
        this.horaEntrada = horaEntrada;
        this.horaSalida = horaSalida;
    }

    public Calendar getHoraEntrada() {
        return horaEntrada;
    }

    public Calendar getHoraSalida() {
        return horaSalida;
    }
}
