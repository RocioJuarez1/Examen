package estacionamientoautomatizado;

import java.util.*;

/**
 * Vehículo abstracto. Superclase de las clases de vehículos reales
 */
public abstract class Vehiculo {

    private String matrícula;
    private Calendar horaEntrada;

    public Vehiculo(String matrícula) {
        this.matrícula = matrícula;
    }

    public String getMatrícula() {
        return matrícula;
    }

    public Calendar getHoraEntrada() {
        return horaEntrada;
    }

    public void comienzaMes() {
    }

    public void finEstancia() {
    }

    public void comienzaEstancia() {
        this.horaEntrada = Calendar.getInstance();
    }
    
      protected int difEnMinutos(Calendar inicio, Calendar fin) {
        long diffMillis = fin.getTimeInMillis() - inicio.getTimeInMillis();
        return (int) (diffMillis / (60 * 1000)); // Convertir de milisegundos a minutos
    }
}
