package estacionamientoautomatizado;

import java.util.Calendar;
import java.util.LinkedList;

/**
 * Vehículo oficial. Lleva la lista de las estancias en el aparcamiento
 * realizadas en el mes en curso
 */
public class VehiculoOficial extends Vehiculo {
// lista de las estancias en el mes en curso

    private LinkedList<Estancia> estancias
            = new LinkedList<Estancia>();

    public VehiculoOficial(String matrícula) {
        super(matrícula);
    }

    public LinkedList<Estancia> getEstancias() {
        return estancias;
    }

    @Override
    public void comienzaMes() {
        estancias.clear(); // borra la lista de estancias
    }

    @Override
    public void finEstancia() {
// añade la estancia a la lista
        estancias.add(new Estancia(getHoraEntrada(), Calendar.getInstance()));
    }
}
