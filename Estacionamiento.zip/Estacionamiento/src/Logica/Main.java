package Logica;

import Conexion.Index;

public class Main {

    public static void main(String[] args) {
        new Index().setVisible(true);
    }
    
}
