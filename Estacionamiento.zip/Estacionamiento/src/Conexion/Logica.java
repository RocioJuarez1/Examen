package Conexion;

import static java.awt.PageAttributes.MediaType.D;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Logica {

    public DefaultTableModel mostrarReporte() {
        String[] nombresColumnas = {"id", "Matricula", "Tiempo Estacionado", "Tipo", "Entrada", "Salida", "Importe"};
        String[] registros = new String[7];

        DefaultTableModel modelo = new DefaultTableModel(null, nombresColumnas);

        String sql = "SELECT * FROM vehiculos";

        Connection cn = null;

        PreparedStatement pst = null;

        ResultSet rs = null;

        try {
            cn = Conexion.conectar();

            pst = cn.prepareStatement(sql);

            rs = pst.executeQuery();

            while (rs.next()) {
                registros[0] = rs.getString("id_vehiculo");

                registros[1] = rs.getString("matricula");

                registros[2] = rs.getString("tiempo_estacionado");
                
                registros[3] = rs.getString("tipo");
                
                registros[4] = rs.getString("entrada");

                registros[5] = rs.getString("salida");
                
                registros[6] = rs.getString("importe");

                modelo.addRow(registros);

            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, "Error al conectar");

        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (pst != null) {
                    pst.close();
                }

                if (cn != null) {
                    cn.close();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        return modelo;
    }
}
